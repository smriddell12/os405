char ** split(char str[], char tok[], int *num_elements);

